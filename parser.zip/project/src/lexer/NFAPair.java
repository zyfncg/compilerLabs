package lexer;

/**
 * Created by ZhangYF on 2016/10/26.
 */
public class NFAPair {
    public NFANode startNode;
    public NFANode endNode;
}
